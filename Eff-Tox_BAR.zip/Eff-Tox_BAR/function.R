### Xmat ###================================================================================================================#
X<-function(n,PI){                      #n= pts per cohort,PI=sampling prob. #
  trt1=c(0,0);trt2=c(1,0);trt3=c(0,1)     
  xm=matrix(0,ncol=n,nrow=3);         #Xij=(xij1,xij2,.....,xijp)T
  
  for(i in 1:n){
    xm[3,i]<- rbinom(1,1,0.5);        #covariate:good=1,bad=0
    ###��PI���ttrt###
    a=c(1,2,3);                      #a=trt indicator,1-trt1, 2-trt2, 3-trt3#
    r=ifelse(xm[3,i]==0,1,2);        #the trt being allocated(1=bad/2=good)#PI[r,]
    trt<-sample(a,1,prob=PI[r,]);    #sampling trt by PI
    if(trt==1){xm[1:2,i]=trt1};     #trt=1(trt1)
    if(trt==2){xm[1:2,i]=trt2};     #trt=2(trt2)
    if(trt==3){xm[1:2,i]=trt3};     #trt=3(trt3)
  }
  return(xm)
}

### generate PFS and censoring indicator ###=============================================================================================#
time<-function(al,lam,b,B,x,n,s){ 
  time=matrix(0,ncol=2,nrow=n);                        
  bx=c(B%*%x)
  for (i in 1:n){
    if(s==0){
      p=runif(1)
      Lt=(-log(1-p)/(lam*b[i]*exp(bx[i])))^(1/al) 
    }
    
    if(s==1){
      p=runif(1)
      Lt= (((1-p)^(-1)-1)/(lam*b[i]*exp(bx[i])))^(1/al);  
    }
    if(s==2){  
      p=runif(1)
      Lt=log((1-(log(1-p)*a1/lam)))/(a1*b[i]*exp(c(B%*%x)))
    }
    
    Ct=runif(1,0.03,1.5)
    t=min(Lt,Ct)
    cen=ifelse(Lt<Ct,1,0) 
    time[i,]<-c(t,cen)
  }
  return(time)
}
### posterior ###=============================================================================================#

###alpha ###
Aposter=function(al,lam,B,b,time,cen,g,x,low,upp){          # alpha
  posterior=al^(g+sum(cen)-1)*(prod(time^cen))^(al-1)*exp(-(al*g)-lam*sum(time^al*b*exp(c(B%*%x))))
  posterior[al>upp | al<low] = 0
  posterior
}

###lambda ###
Lpost=function(al,lam,B,b,time,cen,g,x,low,upp){       #lambda
  posterior=dgamma(lam,g+sum(cen),rate=g+sum(time^al*b*exp(c(B%*%x))))
  posterior[lam>upp | lam<low] = 0;               #low,upp=lambda�d��
  posterior
}

##beta[i] ## ##B=B[1*p],X=X[p*n],p=#of B (the pth beta)
Bposter=function(al,lam,B,b,time,cen,x,low,upp){   
  posterior=exp(sum(cen*(c(B%*%x)))-lam*sum(time^al*b*exp(B*x)))
  posterior[B>upp | B<low ] = 0;             ##range of B= B[low,upp]
  posterior
}
# b~gamma ##b=matrix(1x(i*j)) #                                        
# postertior of the ith b's 
bgposter=function(par,B1,B2,t1,cen1,t2,cen2,th,b,x){
  al1=par[1]; lam1=par[2]; al2=par[3]; lam2=par[4]
  posterior=dgamma(b,th+cen1+cen2,rate=th+lam1*t1^al1*exp(c(B1%*%x))+lam2*t2^al2*exp(c(B2%*%x)))
  posterior   
} 

### samples ###=================================================================================================#
##low,upp
parameter=function(N,n,run,low,upp,parin,tcall){                 
  par=parin$par; B1=parin$B1; B2=parin$B2; x=parin$x; b=parin$b
  t1=tcall$t1; cen1=tcall$cen1; t2=tcall$t2; cen2=tcall$cen2
  AL1=low[1]; AU1=upp[1]; LL1=low[2]; LU1=upp[2]; LL2=low[3]; LU2=upp[3];    
  BL1=low[4:6]; BU1=upp[4:6]; BL2=low[7:9]; BU2=upp[7:9];                     
  ## calculate the freq. of renew 
  a1=0;l1=0;a2=0;l2=0;bb1=c(0,0,0);bb2=c(0,0,0);
  if(n<N){bn=rep(0,N-n+1)}else{bn=0}    
  
  #mat#
  pmat=matrix(0,ncol=4,nrow=run+1,byrow=TRUE)
  Bmat1=matrix(0,ncol=3,nrow=run+1,byrow=TRUE)
  Bmat2=matrix(0,ncol=3,nrow=run+1,byrow=TRUE)
  bmat=matrix(0,ncol=N,nrow=run+1) 
  
  #initial value#
  pmat[1,]=par; Bmat1[1,]=B1; Bmat2[1,]=B2; bmat[1,]=b
  al1=par[1]; lam1=par[2]; al2=par[3]; lam2=par[4]
  
  for (i in 1:run) {
    ##alpl1##
    pold1=Aposter(al1,lam1,B1,b,t1,cen1,g,x,AL1,AU1);        ##the ith poster
    parjump1=rnorm(1,al1,0.3);                               ##next alpha
    pnew1=Aposter(parjump1,lam1,B1,b,t1,cen1,g,x,AL1,AU1);    ##next poster
    prob1=min(pnew1/pold1,1)
    if(runif(1)< prob1){ 
      al1=parjump1
      a1=a1+1
    }else{
      al1=al1
      a1=a1
    }
    
    ##lambda1##
    pold2=Lpost(al1,lam1,B1,b,t1,cen1,g,x,LL1,LU1);      
    parjump2=rnorm(1,lam1,0.01);                         
    pnew2=Lpost(al1,parjump2,B1,b,t1,cen1,g,x,LL1,LU1);  
    prob2=min(pnew2/pold2,1)
    if(runif(1)< prob2){ 
      lam1=parjump2
      l1=l1+1
    }else{
      lam1=lam1
      l1=l1
    }
    
    ##alpha2##
    pold3=Aposter(al2,lam2,B2,b,t2,cen2,g,x,0.7,1);          
    parjump3=rnorm(1,al2,0.3);                             
    pnew3=Aposter(parjump3,lam2,B2,b,t2,cen2,g,x,0.7,1);     
    prob3=min(pnew3/pold3,1)
    if(runif(1)< prob3){ 
      al2=parjump3
      a2=a2+1
    }else{
      al2=al2
      a2=a2
    }
    
    ##lambda2##
    pold4=Lpost(al2,lam2,B2,b,t2,cen2,g,x,LL2,LU2);      
    parjump4=rnorm(1,lam2,0.01);                          
    pnew4=Lpost(al2,parjump4,B2,b,t2,cen2,g,x,LL2,LU2);   
    prob4=min(pnew4/pold4,1)
    if(runif(1)< prob4){ 
      lam2=parjump4
      l2=l2+1
    }else{
      lam2=lam2
      l2=l2
    }
    
    pmat[i+1,]=c(al1,lam1,al2,lam2); # renewed 
    par=c(al1,lam1,al2,lam2)
    
    ##B1##
    for(j in 1:3){
      pold5=Bposter(al1,lam1,B1[j],b,t1,cen1,x[j,],BL1[j],BU1[j])
      parjump5=rnorm(1,B1[j],0.1);                                  
      pnew5=Bposter(al1,lam1,parjump5,b,t1,cen1,x[j,],BL1[j],BU1[j])
      prob5=min(pnew5/pold5,1)
      if(runif(1)< prob5){ 
        B1[j]=parjump5
        bb1[j]=bb1[j]+1
      }else{
        B1[j]=B1[j]
        bb1[j]=bb1[j]
      }
    }
    
    Bmat1[i+1,]=B1;  
    
    ##B2##
    for(j in 1:3){
      pold6=Bposter(al2,lam2,B2[j],b,t2,cen2,x[j,],BL2[j],BU2[j])
      parjump6=rnorm(1,B2[j],0.1);                                  
      pnew6=Bposter(al2,lam2,parjump6,b,t2,cen2,x[j,],BL2[j],BU2[j])
      prob6=min(pnew6/pold6,1)
      if(runif(1)< prob6){ 
        B2[j]=parjump6
        bb2[j]=bb2[j]+1
      }else{
        B2[j]=B2[j]
        bb2[j]=bb2[j]
      }
    }
    
    Bmat2[i+1,]=B2;      # renewed    
    
    ##b~gamma##
    if(n<N){
      for(h in n:N){        
        pold7=bgposter(par,B1,B2,t1[h],cen1[h],t2[h],cen2[h],th,b[h],x[,h])
        parjump7=rnorm(1,bmat[1,h],1.5)
        pnew7=bgposter(par,B1,B2,t1[h],cen1[h],t2[h],cen2[h],th,parjump7,x[,h])
        prob7=min(pnew7/pold7,1)
        if(runif(1)< prob7){ 
          b[h]=parjump7
          bn[h-n+1]=bn[h-n+1]+1
        }else{
          b[h]=b[h]
          bn[h-n+1]=bn[h-n+1]
        }
      }
    }
    bmat[i+1,]=b;  # renewed
    
  } #end of run#
  rr=c(a1/run,l1/run,a2/run,l2/run,bb1/run,bb2/run,bn/run)
  return(list("par"=pmat,"Beta1"=Bmat1,"Beta2"=Bmat2,"b"=bmat,"rr"=rr))
}

### plot jointposterior =====================================================================================#

joinp=function(mpar,mB1,mB2,mb,x,tcall,g,th){
  al1=mpar[,1]; lam1=mpar[,2]; al2=mpar[,3]; lam2=mpar[,4]
  t1=tcall$t1; cen1=tcall$cen1; t2=tcall$t2; cen2=tcall$cen2
  k=length(al1)
  joinposterior=NULL
  for(i in 1:k){
    joinposterior[i]=prod((al1[i]*lam1[i]*t1^al1[i]*mb[i,]*exp(c(mB1[i,]%*%x)))^cen1*exp(-lam1[i]+t1^al1[i]*mb[i,]*exp(c(mB1[i,]%*%x))))*
      prod((al2[i]*lam2[i]*t2^al2[i]*mb[i,]*exp(c(mB2[i,]%*%x)))^cen2*exp(-lam2[i]+t2^al2[i]*mb[i,]*exp(c(mB2[i,]%*%x))))*
      dgamma(al1[i],g,rate=g)*dgamma(lam1[i],g,rate=g)*dgamma(al2[i],g,rate=g)*dgamma(lam2[i],g,rate=g)*prod(dgamma(mb[i,],th,rate=th))
    joinposterior[i]=joinposterior[i]*(1e+55)
  }
  plot(qq,joinposterior,type="l",xlab="times",ylim=c(min(joinposterior),max(joinposterior)))
  # return(joinposterior)   
}

### trade-off ###==========================================================================================#

PEij=function(al,lam,B,x,b,s){                            #individual PEi
  tau=1.5
  if(s==0) ST=function(a){exp(-lam*(a^al)*b*exp(c(B%*%x)))};
  if(s==1) ST=function(a){1/(lam*(a^al)*b*exp(c(B%*%x))+1)};
  if(s==2) ST=function(a){exp((lam/al)*(1-exp(al*a*b*exp(c(B%*%x)))))};
  Fs=integrate(ST,0,tau);                              
  p=Fs$value*ST(tau)/tau;                              # p=integral(St,0~tau)*S(tau)/tau 
  return(p) 
}  
PTij=function(al,lam,B,x,b){                              #individual PTi  
  tau=1.5
  St=function(a){1-exp(-lam*(a^al)*b*exp(c(B%*%x)))};  
  Fs=integrate(St,0,tau);                          
  p=Fs$value*St(tau)/tau;    
  return(p) 
}  
PEi=function(al,lam,B,x,b,s){                           #PEi for the ith group
  peij=NULL; nn=length(b)
  for(j in 1:nn){ peij[j]=PEij(al,lam,B,x,b[j],s)}
  PEI=sum(peij)/nn
  return(PEI)
}
PTi=function(al,lam,B,x,b){                           #PTi for the ith group
  ptij=NULL; nn=length(b)
  for(j in 1:nn){ ptij[j]=PTij(al,lam,B,x,b[j])}
  PTI=sum(ptij)/nn
  return(PTI)
}

## calculate Ii
Imfun=function(al1,lam1,al2,lam2,B1,B2,b1,b2,b3,X1,X2,X3,s){
  
  b10=b1[X1[3,]==0]; b11=b1[X1[3,]==1];   #trt10,trt11
  b20=b2[X2[3,]==0]; b21=b2[X2[3,]==1];   #trt20,trt21
  b30=b3[X3[3,]==0]; b31=b3[X3[3,]==1];   #trt30,trt31
  
  # trade-off index
  #trt1 
  if(length(b10)==0){Pe10=0; Pt10=0; I10=0}
  else{Pe10=PEi(al1,lam1,B1,x10,b10,s); Pt10=PTi(al2,lam2,B2,x10,b10); I10=Pe10/Pt10}
  
  if(length(b11)==0){Pe11=0; Pt11=0; I11=0}
  else{Pe11=PEi(al1,lam1,B1,x11,b11,s); Pt11=PTi(al2,lam2,B2,x11,b11); I11=Pe11/Pt11}
  #trt2 
  if(length(b20)==0){Pe20=0; Pt20=0; I20=0}
  else{Pe20=PEi(al1,lam1,B1,x20,b20,s); Pt20=PTi(al2,lam2,B2,x20,b20); I20=Pe20/Pt20}
  
  if(length(b21)==0){Pe21=0; Pt21=0; I21=0}
  else{Pe21=PEi(al1,lam1,B1,x21,b21,s); Pt21=PTi(al2,lam2,B2,x21,b21); I21=Pe21/Pt21}
  #trt3 
  if(length(b30)==0){Pe30=0; Pt30=0; I30=0}
  else{Pe30=PEi(al1,lam1,B1,x30,b30,s); Pt30=PTi(al2,lam2,B2,x30,b30); I30=Pe30/Pt30}
  
  if(length(b31)==0){Pe31=0; Pt31=0; I31=0}
  else{Pe31=PEi(al1,lam1,B1,x31,b31,s); Pt31=PTi(al2,lam2,B2,x31,b31); I31=Pe31/Pt31}
  
  Im=matrix(c(I10,I20,I30,I11,I21,I31),nrow=2,byrow=TRUE)
  return(Im)
}

##IKi
IKi=function(I,r,i){I[r,i]/sum(I[r,])};   #randomization prob.


### functions  ###=========================================================#
### survival function for different distribution ###
st<-function(al,lam,B,x,b,t,s){ 
  if(s==0){ST=exp(-lam*(t^al)*b*exp(c(B%*%x)))};             #weibull-cox
  if(s==1){ST=1/(lam*(t^al)*b*exp(c(B%*%x))+1)};             #log-logistic    
  if(s==2){ST=exp((lam/al)*(1-exp(al*t*b*exp(c(B%*%x)))))};  #gompertz
  return(ST) 
}

### stopping rule ###==========================================================#
pht=0.3;phe=0.4;ct=ce=0.9

EFFrule=function(al,lam,B,x,b,s){                    #par=par[1:2] or par[3:4]          
  STE=NULL; nn=length(b)
  for(i in 1:nn){
    STE[i]=st(al,lam,B,x[,i],b[i],1.5,s);   ##Ste(t|X)#
  }
  pre=length(which(STE < phe))/nn;          ##Pr(ste <0.4) ineffective#
  return(pre)
}
TOXrule=function(al,lam,B,x,b){                      #par=par[1:2] or par[3:4]     
  STT=NULL; nn=length(b);s=0
  for(i in 1:nn){
    STT[i]=st(al,lam,B,x[,i],b[i],1.5,s);   ##Stt(t|X)#
  }
  prt=length(which((1-STT) > pht))/nn;      ##Pr(1-stt >0.3) over tox#
  return(prt)
}

STOP=function(Im,al1,lam1,al2,lam2,B1,B2,X1,X2,X3,b1,b2,b3,s){      
  if(length(b1)==0){pre1=0; prt1=0}
  else{ pre1=EFFrule(al1,lam1,B1,X1,b1,s); prt1=TOXrule(al2,lam2,B2,X1,b1)}
  if(length(b2)==0){pre2=0; prt2=0}
  else{ pre2=EFFrule(al1,lam1,B1,X2,b2,s); prt2=TOXrule(al2,lam2,B2,X2,b2)}  
  if(length(b3)==0){pre3=0; prt3=0}
  else{ pre3=EFFrule(al1,lam1,B1,X3,b3,s); prt3=TOXrule(al2,lam2,B2,X3,b3)}
  
  PRE=c(pre1,pre2,pre3); PRT=c(prt1,prt2,prt3)
  mpr=rbind(PRE,PRT)
  Im[,1]=if(any(mpr[,1] > 0.9)) Im[,1]=0 else Im[,1]=Im[,1];  ##EFF.TOXrule>0.9 stop the trial#
  Im[,2]=if(any(mpr[,2] > 0.9)) Im[,2]=0 else Im[,2]=Im[,2];
  Im[,3]=if(any(mpr[,3] > 0.9)) Im[,3]=0 else Im[,3]=Im[,3];
  return(Im)
}

## numbers of censoring ##===================================================================================================================================#
cennum=function(xmat,cen){
  # no. of (cen=1) 
  if(cen=="cen1"){xmat=filter(xmat,cen1==1)}
  if(cen=="cen2"){xmat=filter(xmat,cen2==1)}
  nc10=length(which(xmat$X1==0 & xmat$X2==0 & xmat$X3==0)) 
  nc11=length(which(xmat$X1==0 & xmat$X2==0 & xmat$X3==1)) 
  nc20=length(which(xmat$X1==1 & xmat$X2==0 & xmat$X3==0)) 
  nc21=length(which(xmat$X1==1 & xmat$X2==0 & xmat$X3==1))
  nc30=length(which(xmat$X1==0 & xmat$X2==1 & xmat$X3==0)) 
  nc31=length(which(xmat$X1==0 & xmat$X2==1 & xmat$X3==1))
  
  # censorig for each trt   
  # the order is trt1(0,1)-trt2(0,1)-trt3(0,1)
  nc=c(nc10,nc11,nc20,nc21,nc30,nc31)  
  return(nc)
}

### trial time  ###=====================================================================================================#
ALLT<-function(xmat,time){
  if(time=="t1"){txmat=xmat %>% filter(.,maxtime>0) %>% mutate(.,totaltime=m+t1)}
  if(time=="t2"){txmat=xmat %>% filter(.,maxtime>0) %>% mutate(.,totaltime=m+t2)}
  if(time=="maxtime"){txmat=xmat %>% filter(.,maxtime>0) %>% mutate(.,totaltime=m+maxtime)}
  time=max(txmat$totaltime) 
  return(time)      
}