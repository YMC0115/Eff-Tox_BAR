
cat(" Scenario: ",fn,"-",scenario,"\n",
    "Time Spend: ",m1,m2,mT,"\n",
    "#of pts: ",round(NALL),"\n","#of TOX: ",round(N2,0),"\n","#of EFF: ",round(N1,0),"\n",
    "selection prob: ",SP,"\n",
    "selection prob(0.025): ",SP_L,"\n",
    "selection prob(0.975): ",SP_U,"\n","\n",
    file=paste0(path,"/result/result.txt"),append=TRUE) 

