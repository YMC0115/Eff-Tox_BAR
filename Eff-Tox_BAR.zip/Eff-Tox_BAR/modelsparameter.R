models<-function(fn,scenario){  
  bon=0.2 
  if(fn=="bivariate"){
    s=0
    par=c(0.8,0.3,0.8,0.13) 
    tau=1.5;g=0.01;th=10;             # the parameters in alpha,lambda and b
    if(scenario==1){
      B1=c(0,0,-0.01);    B2=c(0.25,0.45,0)              # scenario 1 
    }
    if (scenario==2){
      B1=c(-0.3,-0.8,0);  B2=c(0,0,-0.01)              # scenario 2 
    }
    if (scenario==3){
      B1=c(-0.1,-0.2,0);  B2=c(-0.4,0.3,0)            # scenario 3 
    }
    if (scenario==4){
      B1=c(-0.1,-0.6,0);  B2=c(0.2,-0.6,0)             # scenario 4 
    }
    if (scenario==5){
      B1=c(0,0,-0.001);    B2=c(0,0,-0.001);             # scenario 5 
    }
    if(scenario==6){
      B1=c(0.9,-0.1,0);  B2=c(0.9,0.9,0);              # scenario 6
    }
    low=c(par[1],par[2],par[4],B1,B2)-bon
    upp=c(par[1],par[2],par[4],B1,B2)+bon
  }
  if(fn=="vague"){
    s=0
    par=c(0.8,0.3,0.8,0.13) 
    tau=1.5;g=0.001;th=5;            # the parameters in alpha,lambda and b  
    if(scenario==1){
      B1=c(0,0,-0.01);    B2=c(0.25,0.45,0);                 # scenario 1   
    }
    if (scenario==2){
      B1=c(-0.3,-0.8,0);  B2=c(0,0,-0.01);                 # scenario 2  
    }
    if (scenario==3){
      B1=c(-0.1,-0.2,0);  B2=c(-0.4,0.3,0);                # scenario 3 
    }
    if (scenario==4){
      B1=c(-0.1,-0.6,0);  B2=c(0.2,-0.6,0);                # scenario 4   
    }
    low=c(par[1],par[2],par[4],B1,B2)-bon
    upp=c(par[1],par[2],par[4],B1,B2)+bon
  }
  if(fn=="informative"){
    s=0
    par=c(0.8,0.3,0.8,0.13) 
    tau=1.5; g=0.1;  th=20;           # the parameters in alpha,lambda and b  
    if(scenario==1){
      B1=c(0,0,-0.01);    B2=c(0.25,0.45,0);            # scenario 1   
    }
    if (scenario==2){
      B1=c(-0.3,-0.8,0);  B2=c(0,0,-0.01);             # scenario 2  
    }
    if (scenario==3){
      B1=c(-0.1,-0.2,0);  B2=c(-0.4,0.3,0);            # scenario 3  
    }
    if (scenario==4){
      B1=c(-0.1,-0.6,0);  B2=c(0.2,-0.6,0);           # scenario 4  
    }
    low=c(par[1],par[2],par[4],B1,B2)-bon
    upp=c(par[1],par[2],par[4],B1,B2)+bon
  }
  if(fn=="sensitivity1"){
    s=1
    par=c(0.8,0.35,0.8,0.13)
    tau=1.5; g=0.01; th=10;   # the parameters in alpha,lambda and b
    if(scenario==1){
      B1=c(0,0,-0.01);   B2=c(0.2,0.4,0);            # scenario 1 
    }
    if (scenario==2){
      B1=c(-0.3,-0.9,0);  B2=c(0,0,-0.01);            # scenario 2   
    }
    if (scenario==3){
      B1=c(-0.1,-0.2,0); B2=c(-0.5,0.3,0);           # scenario 3
    }
    if (scenario==4){
      B1=c(-0.1,-0.6,0);  B2=c(0.2,-0.6,0);            # scenario 4
    }
    low=c(par[1],par[2],par[4],B1,B2)-bon
    upp=c(par[1],par[2],par[4],B1,B2)+bon
  }
  if(fn=="sensitivity2"){
    s=2
    par=c(0.8,0.1,0.8,0.13)
    tau=1.5; g=0.01; th=10;   # the parameters in alpha,lambda and b
    if(scenario==1){
      B1=c(0,0,-0.01);   B2=c(0.2,0.4,0);            # scenario 1 
    }
    if (scenario==2){
      B1=c(-0.3,-0.9,0);  B2=c(0,0,-0.01);            #scenario 2  
      
    }
    if (scenario==3){
      B1=c(-0.15,-0.2,0); B2=c(-0.5,0.3,0);            #scenario 3   
    }
    if (scenario==4){
      B1=c(-0.1,-0.6,0);  B2=c(0.2,-0.6,0);            #scenario 4
    }
    low=c(par[1],par[2],par[4],B1,B2)-bon
    upp=c(par[1],par[2],par[4],B1,B2)+bon
  }
  return(list(s=s,par=par,tau=tau,g=g,th=th,B1=B1,B2=B2,low=low,upp=upp))
}
s=models(fn,scenario)$s  # distribution 
par=models(fn,scenario)$par  #(al1,lam1,al2,lam2)
al1=par[1];lam1=par[2]; al2=par[3]; lam2=par[4]
g=models(fn,scenario)$g  #eta
th=models(fn,scenario)$th  #theta
B1=models(fn,scenario)$B1  #(Be1,Be2,Be3)
B2=models(fn,scenario)$B2  #(Bt1,Bt2,Bt3)
low=models(fn,scenario)$low  #(al,lam1,lam2,Be1,Be2,Be3,Bt1,Bt2,Bt3)
upp=models(fn,scenario)$upp  #(al,lam1,lam2,Be1,Be2,Be3,Bt1,Bt2,Bt3)
