
# The program contains several function to estimate the parameters in the EffTox trial. 

rm(list=ls())
library(base); library(dplyr)
options(digits=5)
set.seed(1234)

w=1000;                  #number of simulation(1000)
run=2500;burnin=500;     #number iterations in the MCMC procedure   

fn="bivariate";          #bivariate,sensitivity1-2,vague,informative
scenario=1;              #biv:1-6,sen:1-4,vague:1-4,inf:1-6
# set the file path 
path = file.path('D:/Trial2/JBS/Rcode/Eff-Tox_BAR')
#======================================================================#
EffTox=function(w,run,burnin,fn,scenario,path){
source(file.path(paste0(path,"/modelsparameter.r")))  # parameters setting
source(file.path(paste0(path,"/function.r")))         # function
source(file.path(paste0(path,"/trial.r")))            # the proposed method 
source(file.path(paste0(path,"/cat.r")))              # the results
}

EffTox(w,run,burnin,fn,scenario,path)


