SYSTM=Sys.time()
# X3=0 poor status ; X3=1 good status
x10=c(0,0,0); x11=c(0,0,1)
x20=c(1,0,0); x21=c(1,0,1)
x30=c(0,1,0); x31=c(0,1,1)
w=w; run=run; burnin=burnin; g=g; th=th;
par=par; B1=B1; B2=B2; low=low; upp=upp; s=s


## 
XMAT=NULL #
XX=NULL
TIMEEFF=NULL; TIMETOX=NULL; MAXTIME=NULL
TIME=NULL
NUMCEN1=NULL;                       # eff:no. of cen=1
NUMCEN2=NULL;                       # tox:no. of cen=1
NUMMAT=NULL;                        # pts of each trt
STOPIM=NULL;                        # STOP
RANDPROB=NULL;                      # Selection
SPI=NULL;                           # mean Selection
MPAR=NULL;                          # parameters
MBETA=NULL;                         # B1,B2
MB=NULL;                            # b
ARR=NULL;                           # renew prob.
marr=NULL;                          # mean renew prob.

ID=c(1:120)  # total 120 pts



for(v in 1:w){
  
  randprob=NULL # randomization prob. for each 3- pts
  xmat=cbind(ID,matrix(0,nrow = 120,ncol = 8),rep(1:40,each=3)/2,c(0)) %>% as.data.frame()
  colnames(xmat)= c("id","X1","X2","X3","t1","cen1","t2","cen2","b","m","maxtime")
  ## first 30 pts  ##
  PI=matrix(1/3,nrow = 2,ncol = 3,byrow = T)
  N=30
  # x=X(N,PI)
  x=rbind(rep(c(0,1,0),each=10),rep(c(0,0,1),each=10),rep(c(0,1,0,1,0,1),each=5)); #10 pts to each trt
  b=rgamma(N,th,th)
  timeeff=time(al1,lam1,b,B1,x,N,s)
  timetox=time(al2,lam2,b,B2,x,N,0)
  xmat[1:30,2:9]=c(t(x),timeeff,timetox,b)
  for(j in 1:120){
    xmat[j,11]=max(xmat[j,5],xmat[j,7])
  }
  oxmat=filter(xmat,maxtime>0,m+maxtime<=(N+3)/6) 
  usexmat=oxmat
  
  # posterior estimation #
  parin=list(par=par,B1=B1,B2=B2,x=t(oxmat[,2:4]),b=oxmat[,9]) # all parameters
  tcall=list(t1=oxmat[,5],cen1=oxmat[,6],t2=oxmat[,7],cen2=oxmat[,8]) # eff_time.eff_cen.tox_time.tox_cen
  N1=dim(oxmat)[1]; n1=1 
  mat=parameter(N1,n1,run,low,upp,parin,tcall)
  ARR=rbind(ARR,mat$rr[1:11])  
  
  q=20; qq=seq(burnin,run,q); # every 20 number of iterations
  qq=qq[-1]
  mpar=mat$par[qq,]; mB1=mat$Beta1[qq,]; mB2=mat$Beta2[qq,]; mb=mat$b[qq,]
  # joinp(mpar,mB1,mB2,mb,x,tcall,g,th)
  # _2 renewed posterior in MCMC
  par_2=apply(mpar,2,mean) 
  al1_2=par_2[1]; lam1_2=par_2[2]; al2_2=par_2[3]; lam2_2=par_2[4]
  B1_2=apply(mB1,2,mean); B2_2=apply(mB2,2,mean)
  b_2=apply(mb,2,mean)
 
  # x
  x=t(oxmat[,2:4])
  X1=x[,(x[1,]==0 & x[2,]==0)] %>% as.matrix()
  X2=x[,(x[1,]==1 & x[2,]==0)] %>% as.matrix()
  X3=x[,(x[1,]==0 & x[2,]==1)] %>% as.matrix()
  # b
  b=oxmat[,9]
  b1=b_2[(x[1,]==0 & x[2,]==0)]; b2=b_2[(x[1,]==1 & x[2,]==0)]; b3=b_2[(x[1,]==0 & x[2,]==1)]
  # stopping rule
  Im=Imfun(al1_2,lam1_2,al2_2,lam2_2,B1_2,B2_2,b1,b2,b3,X1,X2,X3,s)
  IM=STOP(Im,al1_2,lam1_2,al2_2,lam2_2,B1_2,B2_2,X1,X2,X3,b1,b2,b3,s); # Ii=0
  
  # PI
  PI=matrix(c(IKi(IM,1,1),IKi(IM,1,2),IKi(IM,1,3),IKi(IM,2,1),IKi(IM,2,2),IKi(IM,2,3)),nrow=2,byrow=TRUE)
  # randomization prob.(trt1-0.1,trt2-0.1,trt3-0.1)
  randprob=rbind(randprob,c(PI)) 
  
  ## AR after ER ##
  n=3 # n=3pts/cohort
  # total N=120 pts
  while(N<120){                               
    x=X(n,PI)
    b=rgamma(n,th,th)
    timeeff=time(al1,lam1,b,B1,x,n,s) 
    timetox=time(al2,lam2,b,B2,x,n,0)
    xmat[(N+1):(N+n),2:9]=c(t(x),timeeff,timetox,b)
    for(j in 1:120){
      xmat[j,11]=max(xmat[j,5],xmat[j,7])
    }
    N=N+n
    oxmat=filter(xmat,maxtime>0,m+maxtime<=(N+3)/6) # event
    un_e_bxmat=oxmat %>% filter(!id %in% usexmat$id)
    e_bxmat=oxmat %>% filter(id %in% usexmat$id)
    oxmat=rbind(e_bxmat,un_e_bxmat)
    usexmat=oxmat
    
    # posterior estimation #
    parin=list(par=par,B1=B1,B2=B2,x=t(oxmat[,2:4]),b=oxmat[,9]) # all parameters
    tcall=list(t1=oxmat[,5],cen1=oxmat[,6],t2=oxmat[,7],cen2=oxmat[,8]) # eff_time.eff_cen.tox_time.tox_cen
    
    N1=dim(oxmat)[1]
    if(dim(oxmat)[1]==dim(e_bxmat)[1]){n1=dim(e_bxmat)[1]}else{n1=dim(e_bxmat)[1]+1}
    mat=parameter(N1,n1,run,low,upp,parin,tcall)
    ARR=rbind(ARR,mat$rr[1:11])
    
    mpar=mat$par[qq,]; mB1=mat$Beta1[qq,]; mB2=mat$Beta2[qq,]; 
    if(dim(oxmat)[1]==dim(e_bxmat)[1]){mb=mb}else{mb=cbind(mb,mat$b[qq,n1:N1])}
    # joinp(mpar,mB1,mB2,mb,x,tcall,g,th)
    
    par_2=apply(mpar,2,mean) 
    al1_2=par_2[1]; lam1_2=par_2[2]; al2_2=par_2[3]; lam2_2=par_2[4]
    B1_2=apply(mB1,2,mean); B2_2=apply(mB2,2,mean)
    b_2=apply(mb,2,mean)
    
    # x
    x=t(oxmat[,2:4])
    X1=x[,(x[1,]==0 & x[2,]==0)] %>% as.matrix()
    X2=x[,(x[1,]==1 & x[2,]==0)] %>% as.matrix()
    X3=x[,(x[1,]==0 & x[2,]==1)] %>% as.matrix()
    # b
    b=oxmat[,9]
    b1=b_2[(x[1,]==0 & x[2,]==0)]; b2=b_2[(x[1,]==1 & x[2,]==0)]; b3=b_2[(x[1,]==0 & x[2,]==1)]
    # stopping rule
    Im=Imfun(al1_2,lam1_2,al2_2,lam2_2,B1_2,B2_2,b1,b2,b3,X1,X2,X3,s)
    IM=STOP(Im,al1_2,lam1_2,al2_2,lam2_2,B1_2,B2_2,X1,X2,X3,b1,b2,b3,s); # Ii=0
    
    # PI
    PI=matrix(c(IKi(IM,1,1),IKi(IM,1,2),IKi(IM,1,3),IKi(IM,2,1),IKi(IM,2,2),IKi(IM,2,3)),nrow=2,byrow=TRUE)
    # randprob(trt1-0.1,trt2-0.1,trt3-0.1)
    randprob=rbind(randprob,c(PI))
    
  }   
  
  RANDPROB=rbind(RANDPROB,cbind(c(1:dim(randprob)[1]),randprob))
  STOPIM=rbind(STOPIM,c(IM))
  
  spi=apply(randprob,2,mean)*100 # randprob for one trial
  
  ###summary results ###
  XMAT=rbind(XMAT,xmat)
  MPAR=rbind(MPAR,par_2) # par
  MBETA=rbind(MBETA,c(B1_2,B2_2)) # B1,B2
  MB=rbind(MB,b_2) #  bij
  XX=rbind(XX,t(xmat[,2:4]))
  
  TIMEEFF=rbind(TIMEEFF,xmat[,5])
  TIMETOX=rbind(TIMETOX,xmat[,7])
  MAXTIME=rbind(MAXTIME,xmat[,11])
  TIME=rbind(TIME,c(ALLT(xmat,"t1"),ALLT(xmat,"t2"),ALLT(xmat,"maxtime")))
  
  nce=cennum(xmat,"cen1")
  nct=cennum(xmat,"cen2")
  
  NUMCEN1=rbind(NUMCEN1,nce) # eff:cen=1
  NUMCEN2=rbind(NUMCEN2,nct) # tox:cen=1
  
  SPI=rbind(SPI,spi) # 
  
  num=c(length(which(xmat$X1==0 & xmat$X2==0)),
        length(which(xmat$X1==0 & xmat$X2==0 & xmat$X3==0)),
        length(which(xmat$X1==0 & xmat$X2==0 & xmat$X3==1)),
        length(which(xmat$X1==1 & xmat$X2==0)),
        length(which(xmat$X1==1 & xmat$X2==0 & xmat$X3==0)),
        length(which(xmat$X1==1 & xmat$X2==0 & xmat$X3==1)),
        length(which(xmat$X1==0 & xmat$X2==1)),
        length(which(xmat$X1==0 & xmat$X2==1 & xmat$X3==0)),
        length(which(xmat$X1==0 & xmat$X2==1 & xmat$X3==1)))
  NUMMAT=rbind(NUMMAT,num) # w
  arr=apply(ARR,2,mean)  #renew prob.
  marr=rbind(marr,arr)
  print(v)
}

m1=mean(TIME[,1])
m2=mean(TIME[,2])
mT=mean(TIME[,3])
# 3 mean pts for each trt group: trt1(all,0,1)--trt2(all,0,1)--trt3(all,0,1)
NALL=apply(NUMMAT,2,mean)
# 4 mean pts of eff:cen=1: trt1(0,1)-trt2(0,1)-trt3(0,1)
N1=apply(NUMCEN1,2,mean) 
# 5 mean pts of tox:cen=1:trt1(0,1)-trt2(0,1)-trt3(0,1)
N2=apply(NUMCEN2,2,mean) 
# 6 mean selction probability: trt1(0,1)-trt2(0,1)-trt3(0,1)
SP=apply(SPI,2,mean) 
SP_L=apply(SPI,2,function(a)quantile(a,0.025)) 
SP_U=apply(SPI,2,function(a)quantile(a,0.975)) 

MRANDPROB = RANDPROB %>% data.frame() %>% group_by(X1) %>% 
  summarise(asign_1_0=mean(X2),asign_1_1=mean(X3),
            asign_2_0=mean(X4),asign_2_1=mean(X5),
            asign_3_0=mean(X6),asign_3_1=mean(X7))

# mean renewed prob.
MARR=apply(marr,2,mean)

# pritn the results #
cat("Scenario: ",fn,"-",scenario,"\n",
    "Time Spend: ",m1,m2,mT,"\n",
    "#of pts: ",NALL,"\n","#of TOX: ",N2,"\n","#of EFF: ",N1,"\n",
    "selection prob: ",SP,"\n",
    "selection prob(0.025): ",SP_L,"\n",
    "selection prob(0.975): ",SP_U,"\n","\n")

rtime=Sys.time()-SYSTM

cat(rtime,"\n","\n")